import 'package:flutter/material.dart';

void main()=>runApp(MessageScreen());

class MessageScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Message Screen"),
      ),
      body: Center(
        child: Text("这是Message界面"),
      ),
    );
  }
}
