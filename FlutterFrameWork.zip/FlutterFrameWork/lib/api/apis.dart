


/// 网络请求接口

class Api {


  static final String movieUrl = "https://gitee.com/null_587_5980/FrameWork/raw/master/app/src/main/movie.json";
  static final String userUrl = "https://gitee.com/null_587_5980/FrameWork/raw/master/app/src/main/user.json";
  static final String user1Url = "https://gitee.com/null_587_5980/FrameWork/raw/master/app/src/main/user1.json";

  static final String baseUrl = "https://www.ruxieducation.com:15443/";
  static final String setDrawProbability = "smokeShop/bonusPoints/setDrawProbability";
  static final String setServicePhoneNumber = "smokeShop/comm/setServicePhoneNumber";


}